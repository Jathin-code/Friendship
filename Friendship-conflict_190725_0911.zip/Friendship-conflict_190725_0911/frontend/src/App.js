import React from "react";
import "./App.css";
import PremiumFriendshipExperience from "./components/PremiumFriendshipExperience";

function App() {
  return (
    <div className="App">
      <PremiumFriendshipExperience />
    </div>
  );
}

export default App;